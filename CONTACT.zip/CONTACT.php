<?php
include_once 'header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
 
        <link href="bootstrapfile/bootstrap-4.3.1-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrapfile/bootstrap-4.3.1-dist/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        
    </head>
    <body>
        <div class="container-fluid" style="height:680px">
            <div class="row">
            <div class="col-lg-5">
                
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!
                        1d14000.170066870116!2d77.29797765000004!3d28.688374749999987!2
                        m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfb88ae17f825%3
                        A0xf41a8fb8cda446c3!2sB-40%2C+Loni+Rd%2C+Oldanpur%2C+Block+B%2C+Balbir+Nagar%2C+Shahd
                        ara%2C+Delhi%2C+110032!5e0!3m2!1sen!2sin!4v1563988323425!5m2!1sen!2sin" 
                        width="565" height="300" frameborder="0" style="border:1px solid palegoldenrod;margin-left:-18px;margin-top:4px;"></iframe>
            </div>
            <div class="col-lg-7">
                <div class="row" style="background-color:graytext;margin-top:4px;">
                <span style="font-size:25px;;margin-left:350px;font-weight:bold;color:white;">  ADDRESS: </span>
               
                </div>
                <br>
                <span style="font-size:20px;margin-left:90px;"> Street no-4, B-40 jyoti colony loni road shahdara delhi-110032 </span>
                <br>
                <span style="font-size:20px;margin-left:90px;"> near govidam banquetee hall.</span>
                <br><br>
                <span style="font-size:20px;margin-left:90px;"> CONTACT US:</span>
                <br>
                <span style="font-size:20px;margin-left:90px;"> MObile no-8800474363</span>
                <br>
                <span style="font-size:20px;margin-left:90px;"> Phone no-011-22820600</span>
                <br>
                <span style="font-size:20px;margin-left:90px;"> mail id-destinationplanning@gmail.com</span>
                
            </div>
        </div>
            <br>
            <div class="row">
                
              
                <div class="col-lg-6">
                                      <img src="  http://whparanormal.weebly.com/uploads/1/6/2/9/16299782/1502562_orig.jpg" style="width:500px;height:300px;margin-top:25px;margin-left:10px;"/>
  
                </div>
                    <div class="col-lg-5" style="margin-bottom:5px;">
                    
                    <form method="post">
                        <h3 style="margin-left:80px;">  CONTACT US FOR QUERIES</h3>
                        <span style="color:red;">*</span><label>NAME</label><input type="text"  class="input-group" />
                       <span style="color:red;">*</span>     <label>E-MAIL</label><input type="text" class="input-group"/>
                       <span style="color:red;">*</span>     <label>PHONE NO.</label><input type="text" class="input-group"/>
                            <label>ADDRESS</label><input type="text" class="input-group"/><br>
                            <input type="submit" value="submit" class="btn-primary"/>
                           
                        </form>
                </div>
        </div>
        </div>
        </body>
</html>
<br>
<?php include_once 'footer.php'?>;
